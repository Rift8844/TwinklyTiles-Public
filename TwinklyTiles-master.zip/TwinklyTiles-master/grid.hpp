
//Idek if this wrapper is fucking worth it lol
//yup it fucking wasnt lol

#pragma once

#include <vector>
#include <iostream>
#include <bitset>

//Much better
class Grid {
	using Chunk = uint64_t;
	static constexpr int CHUNK_LEN = 8;

	struct Edges {
		bool top;
		bool bottom;
		bool left;
		bool right;
	};

	std::vector<Chunk> chunks;
	int cols, rows;

	static Chunk positionMask(int x, int y, Chunk mask = 0b1) {
		int shiftVal = (CHUNK_LEN*CHUNK_LEN-1 - (y*CHUNK_LEN+x));

		Chunk normalMask = mask<<shiftVal;
		Chunk specialMask = mask>>(-shiftVal);

		return shiftVal >= 0 ? normalMask : specialMask;
	}

	Chunk& chunkAt(int x, int y) {
		return chunks[y/CHUNK_LEN*cols/CHUNK_LEN + x/CHUNK_LEN];
	}

	Chunk chunkAt(int x, int y) const {
		return chunks[y/CHUNK_LEN*cols/CHUNK_LEN + x/CHUNK_LEN];
	}

	//For debugging
	static void outputChunk(Chunk chnk);

public:

	enum Direction {
		UP, DOWN, LEFT, RIGHT
	};

	Grid(int cols, int rows) : cols{((cols-1)/CHUNK_LEN+1)*CHUNK_LEN}, rows{((rows-1)/CHUNK_LEN+1)*CHUNK_LEN} {
		//Round to nearest chunk len
		chunks = std::vector<Chunk>(cols*rows/CHUNK_LEN/CHUNK_LEN);
	}

	bool get(int x, int y) const; 
	void set(int x, int y, bool val);

	int neighborCount(int x, int y);

	int getCols() const { return cols; }
	int getRows() const { return rows; }

	void correctSize();
};


std::ostream& operator<<(std::ostream& os, Grid& grid);

void graphNeighborCounts(Grid& grid);


