#include "grid.hpp"
#include <iomanip>
#include <bit>
#include <string>

bool Grid::get(int x, int y) const {
	
	Chunk mask = (0 <= x && x < cols ? 0b1 : 0);
	mask = 		 (0 <= y && y < rows ? mask : 0);

	return chunkAt(x, y)&positionMask(x%CHUNK_LEN, y%CHUNK_LEN, mask);
}

void Grid::set(int x, int y, bool val) {

	Chunk& chnk = chunkAt(x, y);

	int localX = x%CHUNK_LEN;
	int localY = y%CHUNK_LEN;

	Chunk setFilled = chnk|positionMask(localX, localY);
	Chunk setEmpty = chnk&(~positionMask(localX, localY));

	chnk = val ? setFilled : setEmpty;
}

int Grid::neighborCount(int x, int y) {
	int localX = x%CHUNK_LEN;
	int localY = y%CHUNK_LEN;

	int count = 0;

	Chunk constexpr COLUMN_NGHBR_MASK = 0x10101;
	Chunk constexpr ROW_NGHBR_MASK = 0b111;

	bool rightEdge = localX == CHUNK_LEN-1 && x < cols-1;
	bool leftEdge = localX == 0 && x > 0;
	bool topEdge = localY == 0 && y > 0;
	bool bottomEdge = localY == CHUNK_LEN-1 && y < rows;

	if (rightEdge) {
		Chunk trailMask = positionMask(0, localY+1, COLUMN_NGHBR_MASK);
		count += std::popcount(chunkAt(x+1, y)&trailMask);
	} else if (leftEdge) {
		Chunk trailMask = positionMask(CHUNK_LEN-1, localY+1, COLUMN_NGHBR_MASK);
		count += std::popcount(chunkAt(x-1, y)&trailMask);
	}

	
	if (topEdge) {
		Chunk constexpr BLEED_MASK = 0x00000000000000ff;
		Chunk trailMask = positionMask(localX+1, CHUNK_LEN-1, ROW_NGHBR_MASK);
		count += std::popcount(chunkAt(x, y-1)&trailMask&BLEED_MASK);

		if (rightEdge) {
			count += get(x+1, y-1);
		} else if (leftEdge) {
			count += get(x-1, y-1);
		}

	} else if (bottomEdge) {
		Chunk constexpr BLEED_MASK = 0xff00000000000000;
		Chunk trailMask = positionMask(localX+1, 0, ROW_NGHBR_MASK);
		count += std::popcount(chunkAt(x, y+1)&trailMask&BLEED_MASK);

		
		if (rightEdge) {
			count += get(x+1, y+1);
		} else if (leftEdge) {
			count += get(x-1, y+1);
		}
	}


	//Will need to be altered with bigger chunks
	Chunk BLEED_MASK = 0xffffffffffffffff;
	BLEED_MASK = localX==CHUNK_LEN-1 ? 0x7f7f7f7f7f7f7f7f : BLEED_MASK;
	BLEED_MASK = localX==0 ? 0xfefefefefefefefe : BLEED_MASK;

	//Same for all chunk sizes
	Chunk constexpr NEIGHBOR_MASK = 0x70507;

	count += std::popcount(chunkAt(x, y)&positionMask(localX+1, localY+1, NEIGHBOR_MASK)&BLEED_MASK);

	return count;
}

//yeah you're supposed to make this jawn const but
//this is only temporary so it's ok if it's crap
std::ostream& operator<<(std::ostream& os, Grid& grid) {
	std::string const FILLED = "██";
	std::string const EMPTY = "  ";

	std::cout << "  ";
	for (int x = 0; x < grid.getCols(); x++)
		std::cout << std::setw(2) << std::left << x;

	std::cout << std::endl;

	for (int y = 0; y < grid.getRows(); y++) {
		std::cout << std::setw(2) << std::left << y;

		for (int x = 0; x < grid.getCols(); x++) {
			os << (grid.get(x, y) ? FILLED : EMPTY);
		}

		os << " |\n";
	}

	return os << std::flush;
}


void Grid::correctSize() {

	Chunk constexpr TOP_EDGE_MASK = 0xff00000000000000;
	Chunk constexpr BOTTOM_EDGE_MASK = 0xff;
	Chunk constexpr LEFT_EDGE_MASK = 0x8080808080808080;
	Chunk constexpr RIGHT_EDGE_MASK = 0x0101010101010101;

	bool resize = false;

	int newCols = cols;
	int newRows = rows;
	int xOrigin = 0;
	int yOrigin = 0;

	for (int x = 0; x < getCols(); x += CHUNK_LEN) {
		if (chunkAt(x, 0)&TOP_EDGE_MASK) {
			resize = true;
			newRows += CHUNK_LEN;
			yOrigin += CHUNK_LEN;
			break;
		}
	}

	for (int x = 0; x < getCols(); x += CHUNK_LEN) {
		if (chunkAt(x, rows-1)&BOTTOM_EDGE_MASK) {
			resize = true;
			newRows += CHUNK_LEN;
			break;
		}
	}

	for (int y = 0; y < getRows(); y += CHUNK_LEN) {
		if (chunkAt(0, y)&LEFT_EDGE_MASK) {
			resize = true;
			newCols += CHUNK_LEN;
			xOrigin += CHUNK_LEN;
			break;
		}
	}

	for (int y = 0; y < getRows(); y += CHUNK_LEN) {
		resize = true;
		if (chunkAt(cols-1, y)&RIGHT_EDGE_MASK) {
			newCols += CHUNK_LEN;
			break;
		}
	}

	if (resize) {
		std::vector<Chunk> newChunks(newCols*newRows/CHUNK_LEN/CHUNK_LEN);

		for (int y = 0; y < rows; y += CHUNK_LEN) {
			for (int x = 0; x < cols; x += CHUNK_LEN) {

				int newChunkIdx = (y+yOrigin)/CHUNK_LEN*newCols/CHUNK_LEN
				 + (x+xOrigin)/CHUNK_LEN;

				newChunks[newChunkIdx] = chunkAt(x, y);
			}
		}

		cols = newCols;
		rows = newRows;

		chunks = newChunks;
	}
}
