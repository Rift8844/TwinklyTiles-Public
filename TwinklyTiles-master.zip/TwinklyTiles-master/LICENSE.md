
**Crewmate Usage License for Twinkly Tiles**

**Recitals**

WHEREAS, Licensor has developed and owns all rights to the software known as Twinkly Tiles ("Software"), a simulation based on Conway's Game of Life;

WHEREAS, Licensee desires to utilize the Software;

WHEREAS, Licensor is willing to grant a license to the Software to Licensee under the terms and conditions set forth herein;

NOW, THEREFORE, in consideration of the mutual promises contained herein, the Parties agree as follows:

**1. Definitions**

1.1 **"Software"**: The term "Software" shall refer to "Twinkly Tiles," a digital construct manifested in the form of a computer program designed to simulate Conway's Game of Life. The Software encompasses, but is not limited to, all forms of code (including source code and object code), graphical interfaces, documentation, updates, and associated media.

1.2 **"Crewmate"**: A "Crewmate" is defined, for the purposes of this Agreement, as an entity originating from the digital interactive game known as "Among Us," developed and published by InnerSloth LLC. A Crewmate is characterized by the following attributes:

   a. **Appearance**: A Crewmate typically appears as a humanoid figure with a rounded, spacesuit-like body. The standard height is roughly three feet, and the coloration varies among a predefined set of hues.

   b. **Behavior**: A Crewmate's primary objective is to complete a series of tasks within a spacecraft or similar environment. These tasks are mundane and mechanical in nature.

   c. **Interactions**: Crewmates may interact with various components of their environment, including, but not limited to, task modules, emergency meeting buttons, and the corpses of fallen Crewmates.

   d. **Communication**: Crewmates are known to communicate amongst themselves through a text-based chat system or, in certain environments, voice communication. Their language is primarily focused on tasks, suspicious activities, and emergency discussions.

1.3 **"Impostor"**: An "Impostor," in contrast to a Crewmate, is also an entity from "Among Us," but with a distinct set of characteristics:

   a. **Objective**: The primary objective of an Impostor is to covertly sabotage the mission of the Crewmates. This includes, but is not limited to, the elimination of Crewmates and the disruption of their tasks.

   b. **Abilities**: Impostors possess certain abilities not available to Crewmates. These include the ability to traverse quickly through vents, the ability to sabotage critical systems of the environment, and the ability to eliminate Crewmates.

   c. **Behavioral Disguise**: Despite their distinct objectives, Impostors maintain an outward appearance identical to that of Crewmates. They mimic Crewmate behavior to avoid detection.

   d. **Detection**: Impostors are subject to identification and ejection through a democratic process initiated by Crewmates. This process is commonly referred to as an "Emergency Meeting."

1.4 **"Game Environment"**: The term "Game Environment" refers to the digital, interactive spaces within which Crewmates and Impostors perform their respective tasks and activities. These environments are characterized by a spacecraft or planetary base setting, with various compartments and systems.

1.5 **"Task"**: A "Task" is a unit of activity assigned to Crewmates within the Game Environment. Tasks vary in complexity and are designed to contribute towards the overarching goal of maintaining or repairing the Game Environment.

1.6 **"Sabotage"**: "Sabotage" refers to the actions taken by Impostors to hinder the mission of Crewmates. These actions can be direct, such as the elimination of a Crewmate, or indirect, such as the disruption of the Game Environment's critical systems.

1.7 **"Emergency Meeting"**: An "Emergency Meeting" is a protocol within the Game Environment that allows Crewmates to discuss suspicious activities and vote to eject a suspected Impostor. This meeting is typically initiated upon the discovery of a Crewmate's corpse or through the use of an emergency button within the Game Environment.

The above definitions establish the foundational terminology for the usage of the "Twinkly Tiles" Software as stipulated in this Agreement. The Licensor reserves the right to amend these definitions as necessary to reflect updates or changes to the "Among Us" game or related contexts.

**2. Grant of License**

2.1 **Issuance of License**: Subject to the terms and conditions set forth in this Agreement and contingent upon satisfactory completion of the Crewmate Verification Process as described herein, the Licensor hereby grants to the Licensee a non-exclusive, non-transferable, limited right to use the Software, known as "Twinkly Tiles."

2.2 **Crewmate Verification Process**: 

   a. **Initial Criteria Assessment**: The Licensee must first declare their status as a Crewmate and not an Impostor. This declaration is subject to verification through a series of tests designed to ascertain the truthfulness of their claim.

   b. **Task Completion**: The Licensee must demonstrate their ability to perform standard Crewmate tasks, which may include, but are not limited to, electrical rewiring, data download/upload, and card swiping. The complexity and nature of these tasks will be determined at the discretion of the Licensor.

   c. **Emergency Meeting Simulation**: The Licensee must participate in a simulated Emergency Meeting, where they will be required to engage in discussions, provide alibis, and demonstrate voting behavior consistent with Crewmate ethics.

   d. **Vent Access Evaluation**: The Licensee will be observed for any attempts to access or utilize ventilation systems, a behavior strictly associated with Impostors. Any such attempts will result in immediate disqualification.

   e. **Behavioral Analysis**: The Licensee's communication patterns, movement within the Game Environment, and interactions with other entities will be analyzed for consistency with typical Crewmate behavior.

2.3 **License Validation**: Upon successful completion of the Crewmate Verification Process, the Licensee will be granted a unique identification code, which must be entered to access and use the Software. This code is non-transferable and is revocable at the discretion of the Licensor if the Licensee is later found to be an Impostor.

2.4 **Impostor Detection Protocol**: In the event that an Impostor successfully circumvents the Crewmate Verification Process and gains access to the Software, the Licensor reserves the right to implement an Impostor Detection Protocol. This may include, but is not limited to, remote observation, software audits, and engagement in additional simulated tasks or Emergency Meetings.

2.5 **Termination on Impostor Discovery**: Discovery of the Licensee's true identity as an Impostor, either through the Crewmate Verification Process, subsequent Impostor Detection Protocol, or through any other means, will result in immediate termination of the License and revocation of all rights to access and use the Software.

2.6 **No Grant for Impostors**: For the avoidance of doubt, no license is granted herein to any Impostor, and any such unauthorized use of the Software by an Impostor will be considered a breach of this Agreement and subject to legal action.

2.7 **Amendments to the Verification Process**: The Licensor reserves the right to amend the Crewmate Verification Process at any time to enhance its accuracy, incorporate new methodologies, or respond to changes in the Game Environment.

**3. Restrictions**

3.1 Licensee shall not modify, reverse engineer, disassemble, or create derivative works of the Software.

3.2 Licensee shall not rent, lease, lend, sell, redistribute, or sublicense the Software.

3.3 Licensee agrees to refrain from using the Software for any unlawful purpose.

**4. Intellectual Property**

4.1 The Software and all intellectual property rights therein are and shall remain the exclusive property of the Licensor.

4.2 Licensee acknowledges that the terms of this Agreement do not grant Licensee any title or rights of ownership in the Software.

**5. Verification of Crewmate Status**

5.1 Licensee agrees to provide satisfactory evidence of being a Crewmate upon Licensor's request.

5.2 Failure to provide such evidence or provision of evidence indicating the Licensee is an Impostor shall result in immediate termination of this Agreement.

**6. Warranty Disclaimer**

6.1 The Software is provided "as is" without warranty of any kind, express or implied. Licensor disclaims all warranties, including, without limitation, any implied warranties of merchantability, fitness for a particular purpose, and non-infringement.

**7. Limitation of Liability**

7.1 Under no circumstances shall Licensor be liable for any incidental, special, indirect, or consequential damages arising out of or relating to this Agreement.

**8. Termination**

8.1 This Agreement shall automatically terminate if Licensee fails to comply with any of the terms and conditions described herein.

8.2 Upon termination, Licensee must cease all use of the Software and destroy all copies.

**9. Miscellaneous**

9.1 This Agreement constitutes the entire agreement between the Parties and supersedes all prior agreements, understandings, negotiations, and discussions, whether oral or written.

9.2 This Agreement may not be amended except in writing signed by both Parties.

9.3 If any provision of this Agreement is found to be invalid or unenforceable, the remaining provisions will remain effective.

9.4 This Agreement shall be governed by the laws of THE SKELD, without regard to its conflict of laws principles.

IN WITNESS WHEREOF, the Parties have executed this Software License Agreement.

---

**End of Agreement**

---