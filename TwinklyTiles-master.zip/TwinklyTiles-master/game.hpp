
#pragma once

#include <cstddef>
#include <iostream>
#include "grid.hpp"

class Game {
	Grid grid;

public:
	void step(size_t n = 1);
	Game(std::vector<bool> const& state, int cols, int rows);
	
	//bad practce but idc it's just temp lol
	void output();
};
