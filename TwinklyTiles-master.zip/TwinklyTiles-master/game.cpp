
#include "game.hpp"
#include <array>
#include <sstream>
#include <iostream>

void Game::step(size_t steps) {

	for (size_t step = 0; step < steps; step++) {
		grid.correctSize();

		Grid newGrid(grid.getCols(), grid.getRows());
			//on ~840mg Caffeine rn no tolly

			for (int y = 0; y < grid.getRows(); y++) {
				for (int x = 0; x < grid.getCols(); x++) {

					size_t neighbors = 0;
						
					neighbors = grid.neighborCount(x, y);
					
					if (neighbors == 3 || (neighbors == 2 && grid.get(x, y))) {
						newGrid.set(x, y, 1);
					}
				}
			}

		grid = newGrid;
	}
}


Game::Game(std::vector<bool> const& state, int cols, int rows) : grid{Grid(cols, rows)} {

	if (state.size() != cols*rows)
		throw std::exception();
	
	for (int y = 0; y < rows; y++) {
		for (int x = 0; x < cols; x++) {
			grid.set(x, y, state[y*cols + x]);
		}
	}
}

void Game::output() {
	std::cout << grid;
}